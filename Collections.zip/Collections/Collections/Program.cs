﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Collections
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Function & Array

            //int[] SomeValues = { 1, 2, 3, 4, 5, 6,7 };
            //Console.WriteLine("\n\n\t Pass Values: Passing Some Integers....");
            //PrintArray(SomeValues);

            //Console.WriteLine("\n\n\tGot It... Now Returning Values:\n\n\t");

            //string[] ReturnedString = SampleStringArray();

            //foreach (string str in ReturnedString)
            //    Console.WriteLine("\n\n\tValue Fetched: {0}", str);

            #endregion

            #region Understanding System.Array
            //Console.WriteLine("\n\n\t System\'s Array testing.....");

            //string[] stringValues = { "I Love India", "Web Technology is our passion", "Train Yourself...." };

            //Console.WriteLine("\n\n\tInitially the Array was ....");
            //for (int i = 0; i < stringValues.Length; i++)
            //    Console.WriteLine(stringValues[i]);
            //Console.WriteLine("\n");

            ////Reverse the Array.....
            //Array.Reverse(stringValues);

            //Console.WriteLine("\n\n\tThe Reversed Array is....");
            //for (int i = 0; i < stringValues.Length; i++)
            //    Console.WriteLine(stringValues[i] + " ");
            //Console.WriteLine("\n");

            ////You Can Clear Some or all elements from the array....
            //Array.Clear(stringValues, 1, 1);
            //Console.WriteLine("\n\n\tAfter Clearing the Array is....");
            //for (int i = 0; i < stringValues.Length; i++)
            //    Console.WriteLine(stringValues[i]);
            //Console.WriteLine("\n");
            #endregion

            #region Arraylist
            //ArrayList arrLstObj = new ArrayList();
            //arrLstObj.Add("Hello");
            //arrLstObj.Add(1);
            //arrLstObj.Add(3.14159);

            //foreach(object obj in arrLstObj)
            //    Console.WriteLine(obj.ToString());
            #endregion

            #region Stack

            //// FILO/LIFO Data Structure... 
            //// Operations Supported...
            //// Push ==> Adding Elements on the Stack. Technically this is called Top of the stack
            //// Pop ==> Removing Elements from Stack top...
            //// Peek ==> Temporarily pops the element...
            //Stack myStack = new Stack();

            //Console.Write("\n\tEnter 10 values separted by ENTER\n");
            //for (int i = 0; i < 10; i++)
            //    myStack.Push(Console.ReadLine());
            //Console.Write("\n\tElements are as follows:\n");
            //for (int i = 0; i < 10; i++)
            //{
            //    Console.Write("\nElement {0}", myStack.Peek());
            //    myStack.Pop();
            //}

            ////

            #endregion

            #region Stack Generics 
            //Stack<int> stack = new Stack<int>();

            //for(int i=0;i<10;i++)
            //    stack.Push(i);

            //for(int i=0;i<10; i++)
            //    Console.WriteLine(stack.Pop());
            #endregion

            #region Queue

            //Queue....
            //FIFO ==> First in First Out
            // Operations supported
            // Enqueue ==> Adding the element to the Rear Position
            // Dequeue ==> Removing the element from the Front Position


            //Queue myQueue = new Queue();

            //Console.Write("\n\tInsert Values in the Queue: Separte by Enter\n");
            //for (int i = 0; i < 10; i++)
            //    myQueue.Enqueue(Console.ReadLine());

            //Console.Write("\n\tYou have Entered...\n");
            //for (int i = 0; i < 10; i++)
            //    Console.Write("\n\t" + myQueue.Dequeue());

            #endregion

            #region Queue Generics
            //Queue<int> queue = new Queue<int>();

            //for(int i=0;i<10;i++)
            //    queue.Enqueue(i);

            //for(int i=0;i<10;i++)
            //    Console.WriteLine(queue.Dequeue()); ;


            #endregion

            #region Basic List
            //List<int> obj = new List<int>();

            //Console.WriteLine("\n\tEnter 3 values...Separate by Enter\n");
            //for (int i = 0; i < 3; i++)
            //    obj.Add(int.Parse(Console.ReadLine()));

            //Console.WriteLine("\n\tValues in the List...\n*************************************\n");
            //foreach (int valuesInList in obj)
            //{
            //    Console.Write(valuesInList.ToString());
            //    Console.Write("\n");
            //}

            //Console.WriteLine("\n\tReversing the List.................\n");
            ////Reverse the List....
            //obj.Reverse();

            //Console.WriteLine("No of Elements in the List:- " + obj.Count.ToString());
            //Console.WriteLine("\n\tAfter Reversing\n****************************");

            //foreach (int valuesInList in obj)
            //{
            //    Console.Write(valuesInList);
            //    Console.Write("\n");
            //}

            #endregion

            #region Special  List
            //Student stObj = new Student();
            //Student stObj1 = new Student();
            //Student stObj2 = new Student();

            //stObj.Name = "Test";
            //stObj.Phone = "989898";

            //stObj1.Name = "Test-1";
            //stObj1.Phone = "9874612211";

            //stObj2.Name = "Test-3";
            //stObj2.Phone = "9870098700";




            //List<Student> obj = new List<Student>();

            //obj.Add(stObj);
            //obj.Add(stObj1);
            //obj.Add(stObj2);

            //foreach (Student item in obj)
            //{
            //    Console.WriteLine(item.Name);
            //    Console.WriteLine(item.Phone);
            //}


            #endregion

            Console.Write("\n\t\tPRESS ENTER TO TERMINATE");
            Console.ReadLine();

        }

        //Accept Params...
        static void PrintArray(int[] IntegerList)
        {
            for (int i = 0; i < IntegerList.Length; i++)
                Console.WriteLine("\tValue at IntegerList[{0}] is {1}", i, IntegerList[i]);
        }

        //Function Can Return String Values.....
        static string[] SampleStringArray()
        {
            //Array Initialization....
            string[] ListOfValues = { "I", "Love", "India","I","also","Love","Foods" };
            return ListOfValues;
        }
    
    }

    class Student
    {
        public string Name { get; set; }
        public string Phone { get; set; }
    
    }
}
